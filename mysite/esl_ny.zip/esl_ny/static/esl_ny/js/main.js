const sunburstInput=document.getElementById('sunburst-input');
const mapInput=document.getElementById('map-input');
const mapContainer=document.getElementById('map-container');
const sunburstContainer=document.getElementById('sunburst-container');
const selectLanguage=document.getElementById('select-language');
const languageSpeakers=document.getElementById('lang-speakers');
const speakersPercentage=document.getElementById('speakers-percentage');
let activePlots=[]
let savedData={}

initialize();
function initialize(){
    languageChanged();
}

function fetchJsonThen(urlString,thenDoThis){
    const url=(selectLanguage.value)?`/${urlString}/${selectLanguage.value}`:`/${urlString}_all`;
    fetch(url).then(data=>data.json()).then(data=>{
        console.log(data);
        savedData[urlString]=data;
        thenDoThis();
    });
}

function languageChanged(){
    fetchJsonThen('populations',updateSunburst);
    fetchJsonThen('demographic',demoBox);
    fetchJsonThen('communities',updateMap);
}

function optionChanged(item) {
    if (item==mapInput){
        mapContainer.classList.add('forward');
        sunburstContainer.classList.remove('forward');
        mapInput.classList.add('selected');
        sunburstInput.classList.remove('selected');
    } else if (item==sunburstInput){
        mapContainer.classList.remove('forward');
        sunburstContainer.classList.add('forward');
        mapInput.classList.remove('selected');
        sunburstInput.classList.add('selected');
    }
}

function demoBox() {
    const data=savedData.demographic;
    languageSpeakers.innerText=data.totalLEPpopulation.toLocaleString("en-US");
    speakersPercentage.innerHTML=(!Object.keys(data).includes("lepPercentage"))?'':`% of all LEP Speakers:<span class='demo-info'>${data.lepPercentage}%</span>`;
    barGraph();
}
  
function barGraph(){
    if(activePlots.includes('bar')){
        Plotly.purge('bar');
    } else {
        activePlots.push('bar');
    }
    const graphData=savedData.demographic.largestLEPs;
    const communities = graphData.map(row => row.community_district.replace(", ", "<br>"));
    const total_population = graphData.map(row => row.population);
    const hover=Object.keys(savedData.demographic).includes("lepPercentage")?graphData.map(each=>{`${each.borough}<br>${each.language}`}):graphData.map(row => row.borough)
    const barData =[
        {
            y: communities.reverse(),
            x: total_population.reverse(),
            hovertext: hover.reverse(),
            type: "bar",
            marker:{color:"#176F6A"},
            orientation: "h",
        },
    ];
    const div=document.getElementById('bar');
    const dims={height:div.offsetHeight-1,
                width:div.offsetWidth-1};
    console.log(div,dims);
    const barLayout = {
        title: "Largest Community Districts",
        margin: {t: 50, l: 150 ,b:20,r:10},
        height: dims.height,
        width: dims.width,
        paper_bgcolor: "rgba(255, 255, 255, 0)",
        plot_bgcolor:"rgba(255, 255, 255, 0)",
    };
    setTimeout(()=>Plotly.newPlot("bar" , barData , barLayout,{staticPlot: true}),5);
}


function updateSunburst() {
    const data=savedData.populations;
    if(activePlots.includes('sunburst-container')){
        Plotly.purge('sunburst-container');
    } else {
        activePlots.push('sunburst-container');
    }
    const trace = {
        type: "sunburst",
        maxdepth: 3,
        hoverinfo:"label+text+value+percent parent+percent root",
        branchvalues: "total",
        ids: data.list.map(line=>line.id),
        labels: data.list.map(line=>{return line.label.replace(", ", "<br>")}),
        parents: data.list.map(line=>line.parent),
        marker:{line:{color:"white",width:0.3}},
        values: data.list.map(line=>line.value),
        insidetextorientation: 'radial',
        textfont:{size:12,color:"black"}
    };
    const div=document.getElementById('sunburst-container');
    const dims={height:div.offsetHeight-1,
                width:div.offsetWidth-1};
    console.log(div,dims);
    const layout = {
      margin: {l:30,r:30,t:30,b:30},
      paper_bgcolor: "0000",
      height: dims.height,
      width: dims.width,
      sunburstcolorway:["d67616","62aa9f","1c8782","c7531a","a63a24"]
    };
    setTimeout(()=>Plotly.newPlot('sunburst-container', [trace], layout,{staticPlot: true}),5);
}

window.addEventListener("resize", ()=>{
    let doit;
    clearTimeout(doit);
    doit = setTimeout(refreshPlots, 200);
});

function refreshPlots(){
    updateSunburst();
    barGraph();
}